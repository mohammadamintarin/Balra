<?php

return [
    'format_numbers' => true,
    'decimals' => 3,
    'dec_point' => ',',
    'thousands_sep' => '.',
];