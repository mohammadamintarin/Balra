<?php

return [
    'format_numbers' => false,
    'decimals' => 2,
    'dec_point' => '.',
    'thousands_sep' => ',',
];