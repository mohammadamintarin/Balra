<?php

return [

	'persian_alpha' 			=> 'must be a persian alpahbet.',
	'persian_num'				=> 'must be a persian number.',
	'persian_alpha_num'			=> 'must be a persian alpahbet or number.',
	'iran_mobile'				=> 'must be a iran mobile number.',
	'sheba'						=> 'must be a sheba number.',
	'melli_code'				=> 'must be a iran melli code.',
	'is_not_persian'			=> 'could not be contain persian alpahbet or number.',
	'limited_array'				=> 'must ba a array and contain values you define not more.',
	'unsigned_num'				=> 'must be an unsigned number.',
	'alpha_space'				=> 'must be alphabet and space.',
	'a_url'						=> 'url is not correct.',
	'a_domain'					=> 'domain is not correct.',
	'more'						=> 'must be more than parameter.',
	'less'						=> 'must be less than parameter.',
	'iran_phone'				=> 'must be a iran phone number.',
	'iran_phonewith_area_code'	=> 'must be a iran phone number.',
	'card_number'				=> 'must be a valid payment card number.',
	'address'					=> 'must be a correct address.',
	'iran_postal_code'			=> 'must be a iran postal code.',
	'package_name'				=> 'must be a valid package name.'

];
